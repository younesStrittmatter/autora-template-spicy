from autora.theorist.example_theorist import ExampleRegressor


def test():
    theorist = ExampleRegressor()
    assert theorist is not None
