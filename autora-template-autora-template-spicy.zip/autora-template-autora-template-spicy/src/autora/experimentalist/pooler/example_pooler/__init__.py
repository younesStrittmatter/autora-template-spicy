def example_pool(argument: float) -> float:
    """
    Add a description of the pooler here
    Args:
        argument: description of the argument
    Returns: description of the argument

    *Optional*
    Examples:
        These examples add documentations and also work as doctests
        >>> example_pool(1.)
        1.0
    """
    return argument
